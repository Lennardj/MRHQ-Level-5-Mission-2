// ./src/App.js
import React, { useState } from "react";

import "./App.css";
import {
  computerVision,
  isConfigured as ComputerVisionIsConfigured,
} from "./azure-cognitiveservices-computervision";

function App() {
  const [fileSelected, setFileSelected] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [processing, setProcessing] = useState(false);
  //
  //
  // My State for uploading a photo
  // const [selectedFile, setSelectedFile] = useState({});
  // const [isSelected, setIsSelected] = useState(false);
  // My State for uploading a photo
  //
  //
  // const handleChangeUplaod = (e) => {
  //   // My code for input box
  //   setSelectedFile(e.target.files[0]);
  //   console.log(selectedFile);
  //   setIsSelected(true);
  //   // My code for input box
  // };
  const handleChange = (e) => {
    // Original Code for the input box
    setFileSelected(e.target.value);
    // Original Code for the input box
  };
  // const onFileUrlEnteredUpload = (e) => {
  //   // My code for uploading a photo
  //   const formData = new FormData();
  //   formData.append("File", selectedFile);
  //   console.log(formData, selectedFile);
  //   //
  //   //
  //   axios
  //     .post("http://localhost:4000/image", {
  //       body: formData,
  //     })
  //     .then(function (response) {
  //       console.log(response);
  //     })
  //     .catch(function (error) {
  //       console.log(error);
  //     });
  //   // //
  //   // Need to add image url to the analysis function
  //   // computerVision(fileSelected || null).then((item) => {
  //   //   // reset state/form
  //   //   setAnalysis(item);
  //   //   setFileSelected("");
  //   //   setProcessing(false);
  //   //   // Mycode
  //   //   setIsSelected(false);
  //   //   setSelectedFile("");
  //   //   // My code
  //   // });
  //   // My code
  // };
  const onFileUrlEntered = (e) => {
    // hold UI
    setProcessing(true);
    setAnalysis(null);
    // Need to add image url to the analysis function
    computerVision(fileSelected || null).then((item) => {
      // reset state/form
      setAnalysis(item);
      setFileSelected("");
      setProcessing(false);
    });
  };

  // Display JSON data in readable format
  const PrettyPrintJson = (data) => {
    console.log(data.brands[0].name);
    console.log(data);
    //
    const Cars = [
      {
        URL: "https://www.honda.co.nz/assets/resized/sm/upload/gs/p1/y1/le/HR-V-RS-Orchid-White-800x450-resize-0-318-0-178-crop.png?k=8c028d54fe",
        brands: "Honda",
      },
      {
        URL: "https://images.drive.com.au/driveau/image/upload/c_fill,f_auto,g_auto,h_675,q_auto:good,w_1200/cms/uploads/wat9nphkehlrcuvnc66n",
        brands: "Honda",
      },
      {
        URL: "https://resources.stuff.co.nz/content/dam/images/4/y/t/c/s/5/image.related.StuffLandscapeThreeByTwo.1464x976.22qye6.png/1624503033877.jpg",
        brands: "Honda",
      },
      {
        URL: "https://images.dealer.com/ddc/vehicles/2022/Honda/CR-V/SUV/trim_EX_5a1461/color/Platinum%20White%20Pearl-WY-217%2C219%2C214-640-en_US.jpg?impolicy=downsize_bkpt&imdensity=1&w=520",
        brands: "Honda",
      },
      {
        URL: "https://www.driven.co.nz/media/100012507/img_20200808_102353.jpg?width=820",
        brands: "Honda",
      },
    ];
    return (
      <div className="resultsDisplay">
        <h1> This car is a {data.brands[0].name}</h1>
        <p>Here is a list of other cars with similar brand</p>
        <div className="carCard">
          {Cars.filter((car) => car.brands === data.brands[0].name).map(
            (car) => (
              <div className="car-Card">
                <div>{car.brands}</div>
                <img src={car.URL} className="car-image" />
              </div>
            )
          )}
        </div>
        <div>
          <pre>{JSON.stringify(data, null, 2)}</pre>
        </div>
      </div>
    );
  };
  const DisplayResults = () => {
    return (
      <div>
        <h2>Computer Vision Analysis</h2>
        <div>
          <img
            src={analysis.URL}
            height="200"
            border="1"
            alt={
              analysis.description &&
              analysis.description.captions &&
              analysis.description.captions[0].text
                ? analysis.description.captions[0].text
                : "can't find caption"
            }
          />
        </div>
        {PrettyPrintJson(analysis)}
      </div>
    );
  };
  const Analyze = () => {
    return (
      <div className="header-Display">
        <h1>Analyze image</h1>
        {!processing && (
          <div className="infobox">
            <div>
              <label>URL</label>
              <input
                type="text"
                placeholder="Enter URL or leave empty for random image from collection"
                size="50"
                onChange={handleChange}
                // value={selectedFile.url}
              ></input>
              <div>
                <button onClick={onFileUrlEntered}>Analyze</button>
              </div>
            </div>

            {/* <div>
              <div>
                <input
                  type="file"
                  name="file"
                  onChange={handleChange}
                  // value={selectedFile.upload}
                />
                <div>
                  <button onClick={onFileUrlEntered}>Analyse</button>
                </div>
              </div>
            </div> */}
          </div>
        )}
        {processing && <div>Processing</div>}
        <hr />
        {analysis && DisplayResults()}
      </div>
    );
  };
  const CantAnalyze = () => {
    return (
      <div>
        Key and/or endpoint not configured in
        ./azure-cognitiveservices-computervision.js
      </div>
    );
  };

  //
  //
  //
  //
  function Render() {
    const ready = ComputerVisionIsConfigured();
    if (ready) {
      return <Analyze />;
    }
    return <CantAnalyze />;
  }
  return <div>{Render()}</div>;
}
export default App;
